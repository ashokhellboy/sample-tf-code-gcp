package simextract

import (
	"context"
	"fmt"
	"io"
	"log"
	"strings"
	"time"
	"path/filepath"
	"simextract.com/pkg/sim"
	"cloud.google.com/go/storage"
	_ "github.com/GoogleCloudPlatform/functions-framework-go/funcframework"
	"github.com/GoogleCloudPlatform/functions-framework-go/functions"
	"github.com/cloudevents/sdk-go/v2/event"
	
)


var subfolderName string = "imported"

// StorageObjectData contains metadata of the Cloud Storage object.
type StorageObjectData struct {
	Bucket         string    `json:"bucket,omitempty"`
	Name           string    `json:"name,omitempty"`
	Metageneration int64     `json:"metageneration,string,omitempty"`
	TimeCreated    time.Time `json:"timeCreated,omitempty"`
	Updated        time.Time `json:"updated,omitempty"`
}

// simextract is a Cloud Function that processes Cloud Storage events.
func simExtract(ctx context.Context, e event.Event) error {
	var data StorageObjectData
	if err := e.DataAs(&data); err != nil {
		return fmt.Errorf("failed to extract event data: %v", err)
	}
	
	if data.Bucket != "sim_cards" {
		log.Printf("Skipping processing for bucket: %s", data.Bucket)
		return nil
	}
	// Check if the file name contains "imported/"
	if strings.Contains(data.Name, "imported/") {
		log.Printf("Skipping processing for file: %s", data.Name)
		return nil
	}


	if !strings.HasSuffix(strings.ToLower(data.Name), ".xlsx") {
		log.Printf("Cannot process - Invalid file type %s", data.Name)
		return nil
	}

	client, err := storage.NewClient(ctx)
	if err != nil {
		return fmt.Errorf("failed to create Storage client: %v", err)
	}
	defer client.Close()

	reader, err := client.Bucket(data.Bucket).Object(data.Name).NewReader(ctx)
	if err != nil {
		return fmt.Errorf("failed to create object reader: %v", err)
	}
	defer reader.Close()

	fileContent, err := io.ReadAll(reader)
	if err != nil {
		return fmt.Errorf("failed to read file contents: %v", err)
	}

	extractedSimCards, err := sim.ExtractFromExcel(fileContent)
	if err != nil {
		return fmt.Errorf("error extracting SIM cards from Excel files: %v", err)
	}

	err = sim.InsertBulk(extractedSimCards)
	if err != nil {
		return fmt.Errorf("error inserting and updating all SIM cards: %v", err)
	}

	log.Printf("Finished inserting and updating all SIM cards")
    
	// Move the processed file to the subfolder
	newObjectName := filepath.Join(subfolderName, data.Name)

    err = moveObject(ctx, client, data.Bucket, data.Name, data.Bucket, newObjectName)
	if err != nil {
		return fmt.Errorf("failed to move object to subfolder: %v", err)
	}

	log.Printf("Moved file to subfolder: %s", newObjectName)
	
	return nil
}

func init() {
	functions.CloudEvent("SimExtract", simExtract)
}

func moveObject(ctx context.Context, client *storage.Client, srcBucket, srcObject, destBucket, destObject string) error {
	srcObjectHandle := client.Bucket(srcBucket).Object(srcObject)
	destObjectHandle := client.Bucket(destBucket).Object(destObject)

	// Copy the object
	_, err := destObjectHandle.CopierFrom(srcObjectHandle).Run(ctx)
	if err != nil {
		return fmt.Errorf("failed to copy object: %v", err)
	}

	// Delete the original object
	if err := srcObjectHandle.Delete(ctx); err != nil {
		return fmt.Errorf("failed to delete original object: %v", err)
	}

	return nil
}
