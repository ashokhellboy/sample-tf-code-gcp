package models

type SimCard struct {
	Imei1          *string `json:"imei_1"`
	Imei2          *string `json:"imei_2"`
	SkuXid         *string `json:"sku_xid"`
	ShipDate       *string `json:"ship_date"`
	Imsi           *string `json:"imsi"`
	Iccid          *string `json:"iccid"`
	ActivationCode *string `json:"activation_code"`
	SerialNumber   *string `json:"serial_number"`
	ProductGroup   *string `json:"product_group"`
	Category       *string `json:"category"`
}

func (s *SimCard) IsDuplicate(other *SimCard) bool {
	return (s.compareValues(s.Imsi, other.Imsi) || s.compareValues(s.Iccid, other.Iccid) || s.compareValues(s.ActivationCode, other.ActivationCode))
}

func (s *SimCard) IsDuplicateArray(others []SimCard) bool {
	for _, other := range others {
		if s.IsDuplicate(&other) {
			return true
		}
	}
	return false
}

func (s *SimCard) GetValueByHeader(header string) string {
	switch header {
	case "imsi", "iccid", "sku_xid", "ship_date", "activation_code", "serial_number", "imei_1", "imei_2":
		return valueOrEmpty(s.getField(header))
	default:
		return ""
	}
}

func valueOrEmpty(value *string) string {
	if value != nil {
		return *value
	}
	return ""
}

func (s *SimCard) getField(field string) *string {
	switch field {
	case "imsi":
		return s.Imsi
	case "iccid":
		return s.Iccid
	case "sku_xid":
		return s.SkuXid
	case "ship_date":
		return s.ShipDate
	case "activation_code":
		return s.ActivationCode
	case "serial_number":
		return s.SerialNumber
	case "imei_1":
		return s.Imei1
	case "imei_2":
		return s.Imei2
	default:
		return nil
	}
}

func (s *SimCard) compareValues(value1, value2 *string) bool {
	return value1 != nil && value2 != nil && (*value1 == *value2) && (*value1 != "") && (*value2 != "")
}
