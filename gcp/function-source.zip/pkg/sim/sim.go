package sim

import (
	
	"fmt"
	"log"
	
	"strings"
	"time"

	"simextract.com/pkg/db"
	"simextract.com/pkg/gen"
	"simextract.com/pkg/models"

	
	"github.com/tealeg/xlsx"
)

var (
	spinnerChars     string = "-\\|/"
	outputFilePath   string = "./output.sql"
	imsiBase         string = "99988877700"
	iccidBase        string = "9999888877776666"
	internalCategory string = "internal"
)

func startSpinner(done chan bool, entriesLen int) {
	spinner := []string{"-", "\\", "|", "/"}
	i := 0
	for {
		select {
		case <-done:
			return
		default:
			fmt.Printf("\r%s Checking for new SIM cards out of %d", spinner[i], entriesLen)

			time.Sleep(100 * time.Millisecond)
			i = (i + 1) % len(spinner)
		}
	}
}

func isDuplicate(entry models.SimCard, existingSims []models.SimCard) bool {
	for _, sim := range existingSims {
		if entry.IsDuplicate(&sim) {
			return true
		}
	}
	return false
}

// InsertBulk inserts a bulk of SIM card entries into the database.
func InsertBulk(entries []models.SimCard) error {
	queries, err := gen.GenerateSQLImport(gen.SQLImportOpts{
		Simcards: entries,
	})
 
	if err != nil {
		return err
	}

	// Concatenate all queries into a single string
	fullQuery := fmt.Sprintf("%s", queries)

	// Execute the concatenated query
	_, err = db.DB.Exec(fullQuery)
	if err != nil {
		return err
	}

	log.Printf("✅ Inserted %d SIM cards", len(entries))
	log.Printf("✅ Finished inserting all SIM cards")
	return nil
}


// ExtractFromExcel extracts SIM card entries from Excel data.
func ExtractFromExcel(data []byte) ([]models.SimCard, error) {
	var entries, duplicates []models.SimCard
	extractionStart := time.Now()
	csvHeaders := gen.CsvHeaders()
	headersIndexMap := make(map[string]int)

	// Open the XLSX file from the in-memory data
	file, err := xlsx.OpenBinary(data)
	if err != nil {
		log.Fatalf("Failed to open XLSX file: %v", err)
		return nil, err
	}

	sheet := file.Sheets[0]

	headerIndices := make(map[string]int)
	if len(sheet.Rows) > 0 {
		for cellIndex, cell := range sheet.Rows[0].Cells {
			header := strings.ToLower(cell.String())
			if header == "unit_s_n_c" || header == "unit_s_n__c" {
				header = "serial_number"
			} else if header == "activationcode" {
				header = "activation_code"
			}

			if _, ok := headersIndexMap[header]; ok {
				headerIndices[header] = cellIndex
			} else {
				for _, h := range csvHeaders {
					if strings.Contains(header, h) {
						headerIndices[h] = cellIndex
						break
					}
				}
			}
		}
	}

	for rowIndex, row := range sheet.Rows {
		if rowIndex == 0 {
			continue
		}

		var simcard models.SimCard
		for header, index := range headerIndices {
			if index < len(row.Cells) {
				v := row.Cells[index].String()
				switch header {
				case "imei_1":
					simcard.Imei1 = &v
				case "imei_2":
					simcard.Imei2 = &v
				case "imsi":
					if len(v) == 15 && !strings.Contains(v, "999999") {
						simcard.Imsi = &v
					}
				case "iccid":
					if len(v) == 20 {
						simcard.Iccid = &v
					}
				case "sku_xid":
					simcard.SkuXid = &v
				case "ship_date":
					if shipDate, err := time.Parse("01-02-06", v); err == nil {
						shipDateString := shipDate.Format("2006-01-02")
						simcard.ShipDate = &shipDateString
					}
				case "activation_code":
					simcard.ActivationCode = &v
				case "serial_number":
					simcard.SerialNumber = &v
				}
			}
		}

		if *simcard.Iccid == "89901800200200878456" {
			log.Println("✅ 89901800200200878456 found")
		}

		if simcard.Imsi == nil && simcard.Iccid == nil {
			continue
		}

		if !isDuplicate(simcard, entries) {
			entries = append(entries, simcard)
		} else {
			duplicates = append(duplicates, simcard)
		}
	}

	if len(duplicates) > 0 {
		fmt.Printf("\nFound %d duplicates", len(duplicates))
	}
	fmt.Printf("\r🟩 Finished extracting SIM cards in %s\n", time.Since(extractionStart))

	//fmt.Printf("\nFound %d unique SIM cards", len(entries))

	return entries, nil
}
