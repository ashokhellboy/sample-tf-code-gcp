package gen

import (
	"log"
	"fmt"
	"strings"
    "simextract.com/pkg/models"
)

// CsvHeaders returns the CSV headers for SIM card entries.
func CsvHeaders() []string {
	return []string{
		"imsi",
		"iccid",
		"activation_code",
		"imei_1",
		"imei_2",
		"sku_xid",
		"ship_date",
		"serial_number",
	}
}


// SQLImportOpts represents options for SQL import.
type SQLImportOpts struct {
	Simcards []models.SimCard
}

// GenerateSQLImport generates SQL insert statements for SIM card entries.
func GenerateSQLImport(opts SQLImportOpts) ([]string, error) {
	if len(opts.Simcards) == 0 {
		return nil, fmt.Errorf("simcards must be provided")
	}
    log.Printf("simcard length is : %s", len(opts.Simcards))
	var queries []string
	initialQuery := "INSERT INTO sim_cards (imsi, iccid, activation_code, imei_1, imei_2, serial_number, sku_xid, product_group, category)\nVALUES\n"

	for _, entry := range opts.Simcards {
		hasImsi := entry.Imsi != nil && *entry.Imsi != ""
		hasIccid := entry.Iccid != nil && *entry.Iccid != ""

		if !hasImsi && !hasIccid {
			continue
		}

		rowValues := make([]string, 9)
		fields := []*string{entry.Imsi, entry.Iccid, entry.ActivationCode, entry.Imei1, entry.Imei2, entry.SerialNumber, entry.SkuXid, entry.ProductGroup, entry.Category}
		for _, field := range fields {
			if field != nil && *field != "" {
				rowValues = append(rowValues, fmt.Sprintf("'%s'", *field))
			} else {
				rowValues = append(rowValues, "NULL")
			}
		}

		row := fmt.Sprintf(" (%s),", strings.Join(rowValues, ", "))
		queries = append(queries, initialQuery+row)
	}

	finalQuery := "\nON CONFLICT (iccid) DO UPDATE SET sku_xid = EXCLUDED.sku_xid, activation_code = EXCLUDED.activation_code, product_group = EXCLUDED.product_group, serial_number = EXCLUDED.serial_number, imei_1 = EXCLUDED.imei_1, imei_2 = EXCLUDED.imei_2, category = EXCLUDED.category, updated_at = NOW();"
	queries = append(queries, finalQuery)

	return queries, nil
}