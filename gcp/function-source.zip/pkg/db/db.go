package db

import (
	"database/sql"
	"log"
	"os"

	_ "github.com/lib/pq"
)

// DB represents the database connection.
var DB *sql.DB

// InitDb initializes the database connection using the provided DATABASE_URL environment variable.
func InitDb() {
	log.Printf("✅ Getting Environment-varivable ")
	DB_HOST := os.Getenv("DATABASE_URL")
	log.Printf("✅ Environment-varivable DATABASE_URL :%s ", DB_HOST)

	if DB_HOST == "" {
		panic("DATABASE_URL must be set.")
	}

	db, err := sql.Open("postgres", DB_HOST+"?binary_parameters=yes")
	if err != nil {
		log.Println(err)
		panic(err)
	}

	if err = db.Ping(); err != nil {
		log.Println(err)
		panic(err)
	}

	// Set the maximum number of open connections to improve concurrent access.
	db.SetMaxOpenConns(2)

	DB = db
}
